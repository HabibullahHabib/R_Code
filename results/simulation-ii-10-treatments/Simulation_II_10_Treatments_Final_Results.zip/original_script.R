# ============================================================================
# THESIS_HABIB - PAPER SIMULATION II
# 10 treatments + 1 control | unequal variances | covariate-driven MAR
# shrinkage and non-shrinkage proposed many-to-one procedures
# ============================================================================
#
# PURPOSE
#   Extend the reference-paper Simulation II comparison to the CURRENT PAPER
#   setting used in our revised Simulation I.
#
# PAPER SIMULATION I STRUCTURE RETAINED
#   Groups: T0 control + T1,...,T10 treatments
#   Scenario I:  mu = (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
#   Scenario II: mu = (0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 6.0)
#   Unequal marginal variances:
#       T0 = 11.0
#       T1 =  9.0
#       T2 =  9.2
#       T3 =  9.4
#       T4 =  9.6
#       T5 =  9.8
#       T6 = 10.0
#       T7 = 10.2
#       T8 = 10.4
#       T9 = 10.6
#       T10= 10.8
#
# SIMULATION II SETTINGS REQUESTED FOR OUR PAPER
#   N per arm = 40 and 80
#   Expected missing rate = 30%
#   m = 40 imputations
#   10,000 Monte Carlo simulations per N/scenario setting
#   alpha = 0.05
#
# EXPLICIT MAR-COVARIATE EXTENSION
#   X ~ N(0,1), fully observed
#   Corr(X,Y | treatment arm) = rho_xy = 0.50
#   Y_g = mu_g + beta_g X + epsilon_g
#   beta_g = rho_xy * sqrt(sigma_g^2)
#   Var(epsilon_g) = sigma_g^2 * (1-rho_xy^2)
#   Therefore each requested MARGINAL arm variance is preserved.
#
#   logit P(M=1 | X) = alpha_30 + log(2) * X
#   alpha_30 is calibrated so E[P(M=1|X)] = 0.30 under X~N(0,1)
#   M ~ Bernoulli(P(M=1|X)); realized missingness varies by replicate.
#
# MI METHODS - ALL THREE RETAINED
#   1) REG: proper arm-specific Bayesian linear regression Y ~ X
#   2) PMM: arm-specific Type-1 PMM Y ~ X, same-arm donors, K = 5
#   3) PROPENSITY: missing ~ group + X; 3 subclasses WITHIN arm;
#      approximate Bayesian bootstrap donors restricted to the same arm.
#
# SIMULATION II METHODS IN THE TABLE
#   Naive deletion
#   Single group-mean imputation
#   MI + Bonferroni
#   MI + Holm
#   MI + proposed many-to-one procedure
#
# TWO PAPER TABLES ARE PRODUCED
#   A) unequal-variance SHRINKAGE version
#   B) unequal-variance NON-SHRINKAGE version
#
# Bonferroni and Holm use the same heteroscedastic Rubin-pooled pairwise tests
# in both tables. Naive, Single, and Proposed are evaluated with the variance
# version named by the table.
#
# Multiple-imputation cells are displayed as:
#   PS / PMM / RE
# ============================================================================

rm(list = ls())

suppressPackageStartupMessages({
  library(mvtnorm)
  library(dplyr)
  library(tibble)
  library(gt)
  library(parallel)
})

# ---------------------------------------------------------------------------
# 0. SETTINGS
# ---------------------------------------------------------------------------
master_seed <- 20211
set.seed(master_seed)

alpha <- 0.05
mr_fixed <- 0.30
m_imp <- 40L
nsim_main <- 10000L
n_grid <- c(40L, 80L)

# Optional short code check. Keep FALSE for the requested final run.
quick_test <- FALSE
if (quick_test) nsim_main <- 50L

# Parallel settings.
use_parallel <- TRUE
n_cores <- max(1L, parallel::detectCores(logical = TRUE) - 1L)

# Numerical settings for multivariate-t critical values.
qmvt_maxpts <- 50000L
qmvt_abseps <- 1e-6
qmvt_df_rule <- "floor"   # alternatives: "round", "ceiling"

# Treatment structure.
n_treatments <- 10L
group_levels <- paste0("T", 0:n_treatments)
treat_levels <- group_levels[-1]
treat_labels <- paste0(treat_levels, " vs. T0")
k_treat <- length(treat_levels)

# Scenarios - consistent with revised Simulation I.
mu_scen1 <- setNames(rep(0, length(group_levels)), group_levels)
mu_scen2 <- setNames(
  c(0, seq(1.5, by = 0.5, length.out = n_treatments)),
  group_levels
)

# Unequal MARGINAL variances - consistent with revised Simulation I.
sig2 <- setNames(
  c(11.0, seq(9.0, by = 0.2, length.out = n_treatments)),
  group_levels
)

# Covariate/outcome relationship.
rho_xy <- 0.50
if (!is.finite(rho_xy) || abs(rho_xy) >= 1) {
  stop("rho_xy must be strictly between -1 and 1.")
}

beta_x_by_group <- rho_xy * sqrt(sig2)
sigma2_error_by_group <- sig2 * (1 - rho_xy^2)

# MAR strength: one-SD increase in X doubles odds of missing Y.
mar_odds_ratio_per_sd <- 2.0
mar_gamma <- log(mar_odds_ratio_per_sd)

# PMM / propensity settings - consistent with current paper Simulation I.
pmm_donors <- 5L
propensity_groups <- 3L

# ---------------------------------------------------------------------------
# 1. BASIC HELPERS
# ---------------------------------------------------------------------------
mean_mar_probability <- function(alpha0, gamma = mar_gamma) {
  integrate(
    function(z) plogis(alpha0 + gamma * z) * dnorm(z),
    lower = -Inf,
    upper = Inf,
    rel.tol = 1e-10,
    subdivisions = 1000L
  )$value
}

calibrate_mar_intercept <- function(target_rate, gamma = mar_gamma) {
  if (target_rate <= 0 || target_rate >= 1) {
    stop("target_rate must lie strictly between 0 and 1.")
  }

  uniroot(
    function(a) mean_mar_probability(a, gamma) - target_rate,
    interval = c(-20, 20),
    tol = 1e-12
  )$root
}

alpha_mar_30 <- calibrate_mar_intercept(mr_fixed)

as_qmvt_df <- function(df) {
  if (!is.finite(df) || df <= 0) stop("Invalid degrees of freedom.")

  if (qmvt_df_rule == "floor") {
    return(as.integer(max(1, floor(df))))
  }
  if (qmvt_df_rule == "round") {
    return(as.integer(max(1, round(df))))
  }
  if (qmvt_df_rule == "ceiling") {
    return(as.integer(max(1, ceiling(df))))
  }

  stop("Unknown qmvt_df_rule.")
}

safe_solve <- function(M) {
  tryCatch(
    solve(M),
    error = function(e) solve(M + diag(1e-8, nrow(M)))
  )
}

make_corr_safe <- function(V) {
  V <- as.matrix(V)
  V <- (V + t(V)) / 2

  ev <- tryCatch(
    eigen(V, symmetric = TRUE, only.values = TRUE)$values,
    error = function(e) NA_real_
  )

  if (any(!is.finite(ev)) || min(ev, na.rm = TRUE) <= 1e-8) {
    ridge <- if (any(is.finite(ev))) {
      abs(min(ev, na.rm = TRUE)) + 1e-8
    } else {
      1e-6
    }
    diag(V) <- diag(V) + ridge
  }

  corr <- cov2cor(V)
  corr[!is.finite(corr)] <- 0
  diag(corr) <- 1
  corr
}

safe_qmvt_crit <- function(corr, df, alpha_level = alpha, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)

  corr <- as.matrix(corr)
  corr <- (corr + t(corr)) / 2
  diag(corr) <- 1

  if (any(!is.finite(corr))) stop("Non-finite correlation matrix.")

  out <- mvtnorm::qmvt(
    p = 1 - alpha_level,
    tail = "both.tails",
    df = as_qmvt_df(df),
    corr = corr,
    algorithm = mvtnorm::GenzBretz(
      maxpts = qmvt_maxpts,
      abseps = qmvt_abseps
    )
  )

  crit <- as.numeric(out$quantile)
  if (!is.finite(crit) || crit <= 0) stop("qmvt returned an invalid critical value.")
  crit
}

build_U_unequal <- function(s2_vec, n_vec) {
  s2_vec <- s2_vec[group_levels]
  n_vec <- n_vec[group_levels]

  s20 <- s2_vec["T0"]
  n0 <- n_vec["T0"]

  U <- matrix(
    s20 / n0,
    nrow = k_treat,
    ncol = k_treat,
    dimnames = list(treat_labels, treat_labels)
  )

  diag(U) <- vapply(
    treat_levels,
    function(g) s20 / n0 + s2_vec[g] / n_vec[g],
    numeric(1)
  )

  U
}

estimate_alpha_hat <- function(s2_vec, n_vec) {
  s2_vec <- as.numeric(s2_vec)
  n_vec <- as.numeric(n_vec)
  G <- length(s2_vec)

  if (length(n_vec) != G) stop("s2_vec and n_vec lengths do not match.")
  if (any(!is.finite(s2_vec)) || any(!is.finite(n_vec)) || any(n_vec <= 1)) {
    stop("Invalid variance/sample-size input for shrinkage.")
  }

  target <- mean(s2_vec)
  num <- ((G - 1) / G) * sum(2 * s2_vec^2 / (n_vec - 1))
  den <- sum((s2_vec - target)^2)

  if (!is.finite(den) || den <= 1e-12) return(1)

  a_hat <- num / den
  min(max(a_hat, 0), 1)
}

shrink_variances <- function(s2_vec, n_vec) {
  alpha_hat <- estimate_alpha_hat(s2_vec, n_vec)
  target <- mean(s2_vec)
  s2_tilde <- alpha_hat * target + (1 - alpha_hat) * s2_vec

  list(
    s2 = setNames(as.numeric(s2_tilde), names(s2_vec)),
    alpha_hat = alpha_hat
  )
}

# ---------------------------------------------------------------------------
# 2. DATA GENERATION: HETEROSCEDASTIC Y WITH X~N(0,1)
# ---------------------------------------------------------------------------
make_complete_data <- function(n_each, mu_vec, seed) {
  set.seed(seed)

  group <- factor(
    rep(group_levels, each = n_each),
    levels = group_levels
  )

  x <- rnorm(length(group), mean = 0, sd = 1)
  g_char <- as.character(group)

  mu_row <- unname(mu_vec[g_char])
  beta_row <- unname(beta_x_by_group[g_char])
  resid_sd_row <- sqrt(unname(sigma2_error_by_group[g_char]))

  y <- mu_row +
    beta_row * x +
    rnorm(length(group), mean = 0, sd = resid_sd_row)

  tibble(
    group = group,
    x = x,
    y = y
  )
}

# ---------------------------------------------------------------------------
# 3. COVARIATE-DRIVEN BERNOULLI MAR
# ---------------------------------------------------------------------------
impose_missingness_mar <- function(dat, seed) {
  set.seed(seed)
  out <- dat

  p_missing <- plogis(
    alpha_mar_30 + mar_gamma * out$x
  )

  M <- rbinom(
    n = nrow(out),
    size = 1L,
    prob = p_missing
  )

  out$y[M == 1L] <- NA_real_
  out
}

# ---------------------------------------------------------------------------
# 4. ARM-SPECIFIC BAYESIAN REGRESSION Y ~ X
# ---------------------------------------------------------------------------
draw_arm_regression <- function(x_obs, y_obs) {
  n <- length(y_obs)
  X <- cbind(`(Intercept)` = 1, x = x_obs)
  p <- ncol(X)

  if (n <= p) {
    stop(
      paste0(
        "Too few observed outcomes in an arm for Bayesian regression imputation: ",
        "n_obs=", n, ", p=", p, "."
      )
    )
  }

  XtX <- crossprod(X)
  if (qr(XtX)$rank < p) stop("Arm-specific regression design matrix is rank deficient.")

  XtX_inv <- solve(XtX)
  beta_hat <- drop(XtX_inv %*% crossprod(X, y_obs))
  resid <- y_obs - drop(X %*% beta_hat)
  df <- n - p
  sse <- sum(resid^2)

  if (!is.finite(sse) || sse <= 0 || df <= 0) {
    stop("Invalid arm-specific regression fit.")
  }

  sigma2_star <- sse / rchisq(1, df = df)
  V_beta <- sigma2_star * XtX_inv
  L <- t(chol(V_beta))
  beta_star <- beta_hat + drop(L %*% rnorm(p))

  list(
    beta_hat = beta_hat,
    beta_star = beta_star,
    sigma2_star = sigma2_star,
    df = df
  )
}

# ---------------------------------------------------------------------------
# 5. IMPUTATION ENGINES
# ---------------------------------------------------------------------------
# 5a. Regression imputation
impute_regression_once <- function(dat, seed) {
  set.seed(seed)
  out <- dat

  for (g in group_levels) {
    idx <- which(out$group == g)
    obs <- idx[!is.na(out$y[idx])]
    mis <- idx[is.na(out$y[idx])]

    if (!length(mis)) next

    dr <- draw_arm_regression(
      x_obs = out$x[obs],
      y_obs = out$y[obs]
    )

    X_mis <- cbind(`(Intercept)` = 1, x = out$x[mis])
    mu_mis <- drop(X_mis %*% dr$beta_star)

    out$y[mis] <- rnorm(
      length(mis),
      mean = mu_mis,
      sd = sqrt(dr$sigma2_star)
    )
  }

  if (anyNA(out$y)) stop("Regression imputation left missing values.")
  out
}

# 5b. PMM - arm-specific Type-1 PMM, K=5
impute_pmm_once <- function(dat, seed, donors = pmm_donors) {
  set.seed(seed)
  out <- dat

  if (!anyNA(out$y)) return(out)

  for (g in group_levels) {
    idx <- which(out$group == g)
    obs <- idx[!is.na(out$y[idx])]
    mis <- idx[is.na(out$y[idx])]

    if (!length(mis)) next
    if (!length(obs)) stop(paste0("No observed PMM donors in arm ", g, "."))

    dr <- draw_arm_regression(
      x_obs = out$x[obs],
      y_obs = out$y[obs]
    )

    X_obs <- cbind(`(Intercept)` = 1, x = out$x[obs])
    X_mis <- cbind(`(Intercept)` = 1, x = out$x[mis])

    # Type-1 PMM.
    pred_obs <- drop(X_obs %*% dr$beta_hat)
    pred_mis <- drop(X_mis %*% dr$beta_star)

    k_use <- min(as.integer(donors), length(obs))

    for (jj in seq_along(mis)) {
      d <- abs(pred_obs - pred_mis[jj])
      ord <- order(d, runif(length(d)))
      donor_pool <- obs[ord[seq_len(k_use)]]
      donor_row <- sample(donor_pool, size = 1L)
      out$y[mis[jj]] <- out$y[donor_row]
    }
  }

  if (anyNA(out$y)) stop("PMM imputation left missing values.")
  out
}

# 5c. Propensity-score subclassification + approximate Bayesian bootstrap
approx_bayesian_bootstrap <- function(y_obs, n_missing) {
  if (n_missing == 0L) return(numeric(0))
  if (!length(y_obs)) stop("No observed donor values available for ABB.")

  y_star <- sample(
    y_obs,
    size = length(y_obs),
    replace = TRUE
  )

  sample(
    y_star,
    size = n_missing,
    replace = TRUE
  )
}

make_propensity_strata <- function(ps, n_groups = propensity_groups) {
  if (any(!is.finite(ps))) stop("Non-finite propensity score.")

  unique_ps <- sort(unique(ps))
  if (length(unique_ps) == 1L) return(rep.int(1L, length(ps)))

  G <- min(as.integer(n_groups), length(unique_ps))
  score_rank <- rank(unique_ps, ties.method = "average")
  score_group <- ceiling(G * score_rank / length(unique_ps))
  score_group <- pmin(G, pmax(1L, as.integer(score_group)))

  mp <- setNames(
    score_group,
    format(unique_ps, digits = 17, scientific = FALSE)
  )

  as.integer(mp[format(ps, digits = 17, scientific = FALSE)])
}

impute_propensity_once <- function(dat, seed) {
  set.seed(seed)
  out <- dat
  mis <- is.na(out$y)

  if (!any(mis)) return(out)

  psdat <- data.frame(
    missing = as.integer(mis),
    group = out$group,
    x = out$x
  )

  fit <- suppressWarnings(
    glm(
      missing ~ group + x,
      family = binomial(),
      data = psdat
    )
  )

  ps <- as.numeric(
    predict(fit, newdata = psdat, type = "response")
  )

  if (any(!is.finite(ps))) stop("Propensity model produced invalid fitted probabilities.")

  for (g in group_levels) {
    idx_g <- which(out$group == g)
    mis_g <- idx_g[is.na(out$y[idx_g])]
    obs_g <- idx_g[!is.na(out$y[idx_g])]

    if (!length(mis_g)) next
    if (!length(obs_g)) stop(paste0("Treatment arm ", g, " has no observed ABB donors."))

    strata_g <- make_propensity_strata(
      ps[idx_g],
      n_groups = propensity_groups
    )

    strata_ids <- sort(unique(strata_g))

    stratum_center <- vapply(
      strata_ids,
      function(s) mean(ps[idx_g[strata_g == s]]),
      numeric(1)
    )
    names(stratum_center) <- as.character(strata_ids)

    for (s in strata_ids) {
      ids_s <- idx_g[strata_g == s]
      mis_s <- ids_s[is.na(out$y[ids_s])]
      if (!length(mis_s)) next

      obs_s <- ids_s[!is.na(out$y[ids_s])]

      # If a subclass has no observed donor, merge only to the nearest
      # nonempty subclass WITHIN the same treatment arm.
      if (!length(obs_s)) {
        donor_strata <- strata_ids[
          vapply(
            strata_ids,
            function(ss) {
              ids_ss <- idx_g[strata_g == ss]
              any(!is.na(out$y[ids_ss]))
            },
            logical(1)
          )
        ]

        if (!length(donor_strata)) {
          stop(paste0("No observed propensity donor subclass in arm ", g, "."))
        }

        nearest_s <- donor_strata[
          which.min(
            abs(
              stratum_center[as.character(donor_strata)] -
                stratum_center[as.character(s)]
            )
          )
        ]

        donor_ids <- idx_g[strata_g == nearest_s]
        obs_s <- donor_ids[!is.na(out$y[donor_ids])]
      }

      out$y[mis_s] <- approx_bayesian_bootstrap(
        out$y[obs_s],
        length(mis_s)
      )
    }
  }

  if (anyNA(out$y)) stop("Propensity-score imputation left missing values.")
  out
}

make_imputations <- function(dat, method, base_seed) {
  comps <- vector("list", m_imp)

  for (mm in seq_len(m_imp)) {
    this_seed <- base_seed + mm - 1L

    comps[[mm]] <- switch(
      method,
      regression = impute_regression_once(dat, seed = this_seed),
      pmm = impute_pmm_once(dat, seed = this_seed, donors = pmm_donors),
      propensity = impute_propensity_once(dat, seed = this_seed),
      stop("Unknown imputation method.")
    )
  }

  comps
}

# ---------------------------------------------------------------------------
# 6. COMPLETE-DATA / CASE-DELETION HELPERS
# ---------------------------------------------------------------------------
get_group_stats <- function(dat, remove_missing = FALSE) {
  if (remove_missing) dat <- dat[!is.na(dat$y), , drop = FALSE]

  means <- sapply(
    group_levels,
    function(g) mean(dat$y[dat$group == g], na.rm = TRUE)
  )

  vars <- sapply(
    group_levels,
    function(g) var(dat$y[dat$group == g], na.rm = TRUE)
  )

  ns <- sapply(
    group_levels,
    function(g) sum(dat$group == g & !is.na(dat$y))
  )

  list(
    means = setNames(as.numeric(means), group_levels),
    vars = setNames(as.numeric(vars), group_levels),
    n = setNames(as.numeric(ns), group_levels)
  )
}

complete_many_to_one_reject <- function(dat,
                                        use_shrinkage,
                                        alpha_level = alpha,
                                        qseed = NULL) {
  st <- get_group_stats(dat, remove_missing = TRUE)

  if (any(st$n < 2) || any(!is.finite(st$vars))) {
    stop("Too few observed outcomes for complete-data many-to-one analysis.")
  }

  Q <- setNames(
    vapply(
      treat_levels,
      function(g) st$means[g] - st$means["T0"],
      numeric(1)
    ),
    treat_labels
  )

  s2_use <- st$vars
  if (use_shrinkage) {
    s2_use <- shrink_variances(st$vars, st$n)$s2
  }

  U <- build_U_unequal(s2_use, st$n)
  df <- sum(st$n) - length(group_levels)

  crit <- safe_qmvt_crit(
    corr = make_corr_safe(U),
    df = df,
    alpha_level = alpha_level,
    seed = qseed
  )

  rej <- abs(Q) > crit * sqrt(diag(U))
  names(rej) <- treat_levels
  rej
}

single_impute_group_mean <- function(dat) {
  out <- dat

  for (g in group_levels) {
    idx_g <- which(out$group == g)
    miss_g <- idx_g[is.na(out$y[idx_g])]

    if (length(miss_g) > 0L) {
      mu_obs <- mean(out$y[idx_g], na.rm = TRUE)
      if (!is.finite(mu_obs)) {
        stop(paste0("No observed outcome available for single imputation in ", g, "."))
      }
      out$y[miss_g] <- mu_obs
    }
  }

  out
}

# ---------------------------------------------------------------------------
# 7. RUBIN SCALAR POOLING FOR BONFERRONI / HOLM
# ---------------------------------------------------------------------------
pool_scalar_rubin <- function(q_vec, u_vec) {
  m <- length(q_vec)
  qbar <- mean(q_vec)
  ubar <- mean(u_vec)
  b <- if (m > 1L) var(q_vec) else 0
  tvar <- ubar + (1 + 1 / m) * b

  if (!is.finite(tvar) || tvar <= 0) stop("Invalid Rubin scalar total variance.")

  if (b <= 1e-14 || ubar <= 1e-14) {
    nu <- 1e6
  } else {
    r <- ((1 + 1 / m) * b) / ubar
    nu <- if (r <= 1e-14) 1e6 else (m - 1) * (1 + 1 / r)^2
  }

  tstat <- qbar / sqrt(tvar)
  pval <- 2 * pt(-abs(tstat), df = nu)

  list(qbar = qbar, tvar = tvar, df = nu, p = pval)
}

mi_pairwise_pvalues_unequal <- function(comp_list) {
  m <- length(comp_list)
  q_mat <- matrix(NA_real_, nrow = m, ncol = k_treat)
  u_mat <- matrix(NA_real_, nrow = m, ncol = k_treat)

  colnames(q_mat) <- treat_levels
  colnames(u_mat) <- treat_levels

  for (mm in seq_len(m)) {
    st <- get_group_stats(comp_list[[mm]])

    for (jj in seq_along(treat_levels)) {
      g <- treat_levels[jj]

      q_mat[mm, jj] <- st$means[g] - st$means["T0"]
      u_mat[mm, jj] <- st$vars["T0"] / st$n["T0"] +
        st$vars[g] / st$n[g]
    }
  }

  pvals <- vapply(
    seq_along(treat_levels),
    function(jj) pool_scalar_rubin(q_mat[, jj], u_mat[, jj])$p,
    numeric(1)
  )

  names(pvals) <- treat_levels
  pvals
}

# ---------------------------------------------------------------------------
# 8. PROPOSED MI MANY-TO-ONE PROCEDURE: SHRINKAGE OR NON-SHRINKAGE
# ---------------------------------------------------------------------------
mi_proposed_unequal_reject <- function(comp_list,
                                       use_shrinkage,
                                       alpha_level = alpha,
                                       qseed = NULL) {
  m <- length(comp_list)

  Qmat <- matrix(
    NA_real_,
    nrow = m,
    ncol = k_treat,
    dimnames = list(NULL, treat_labels)
  )

  U_array <- array(
    NA_real_,
    dim = c(k_treat, k_treat, m),
    dimnames = list(treat_labels, treat_labels, NULL)
  )

  for (mm in seq_len(m)) {
    st <- get_group_stats(comp_list[[mm]])

    Qmat[mm, ] <- vapply(
      treat_levels,
      function(g) st$means[g] - st$means["T0"],
      numeric(1)
    )

    s2_use <- st$vars
    if (use_shrinkage) {
      s2_use <- shrink_variances(st$vars, st$n)$s2
    }

    U_array[, , mm] <- build_U_unequal(s2_use, st$n)
  }

  Qm <- colMeans(Qmat)
  Ubar <- apply(U_array, c(1, 2), mean)
  B <- cov(Qmat)

  Tm <- Ubar + (1 + 1 / m) * B
  Tm <- (Tm + t(Tm)) / 2

  if (max(abs(B)) <= 1e-14) {
    nu <- 1e6
  } else {
    rm <- (1 + 1 / m) *
      sum(diag(B %*% safe_solve(Ubar))) /
      k_treat

    if (!is.finite(rm) || rm < 0) {
      stop("Invalid relative increase in variance for proposed MI procedure.")
    }

    nu <- if (rm <= 1e-14) {
      1e6
    } else {
      (m - 1) * (1 + 1 / rm)^2
    }
  }

  crit <- safe_qmvt_crit(
    corr = make_corr_safe(Tm),
    df = nu,
    alpha_level = alpha_level,
    seed = qseed
  )

  rej <- abs(Qm) > crit * sqrt(diag(Tm))
  names(rej) <- treat_levels
  rej
}

# ---------------------------------------------------------------------------
# 9. EVALUATE ONE MONTE CARLO DATASET
# ---------------------------------------------------------------------------
evaluate_one_dataset <- function(dat_miss, seed_base, alpha_level = alpha) {
  shrink <- list()
  nonshrink <- list()

  # Naive deletion - evaluated under both variance versions.
  shrink$naive <- complete_many_to_one_reject(
    dat_miss,
    use_shrinkage = TRUE,
    alpha_level = alpha_level,
    qseed = seed_base + 10L
  )

  nonshrink$naive <- complete_many_to_one_reject(
    dat_miss,
    use_shrinkage = FALSE,
    alpha_level = alpha_level,
    qseed = seed_base + 11L
  )

  # Single imputation - evaluated under both variance versions.
  dat_single <- single_impute_group_mean(dat_miss)

  shrink$single <- complete_many_to_one_reject(
    dat_single,
    use_shrinkage = TRUE,
    alpha_level = alpha_level,
    qseed = seed_base + 20L
  )

  nonshrink$single <- complete_many_to_one_reject(
    dat_single,
    use_shrinkage = FALSE,
    alpha_level = alpha_level,
    qseed = seed_base + 21L
  )

  # Helper to evaluate each MI engine only once, then use same completed data
  # for shrinkage and non-shrinkage proposed procedures.
  evaluate_mi_method <- function(method, seed_offset, qseed_offset) {
    comps <- make_imputations(
      dat_miss,
      method = method,
      base_seed = seed_base + seed_offset
    )

    pvals <- mi_pairwise_pvalues_unequal(comps)

    list(
      bonf = p.adjust(pvals, method = "bonferroni") < alpha_level,
      holm = p.adjust(pvals, method = "holm") < alpha_level,
      prop_shrink = mi_proposed_unequal_reject(
        comps,
        use_shrinkage = TRUE,
        alpha_level = alpha_level,
        qseed = seed_base + qseed_offset
      ),
      prop_nonshrink = mi_proposed_unequal_reject(
        comps,
        use_shrinkage = FALSE,
        alpha_level = alpha_level,
        qseed = seed_base + qseed_offset + 1L
      )
    )
  }

  reg <- evaluate_mi_method("regression", 10000L, 101L)
  pmm <- evaluate_mi_method("pmm",        20000L, 201L)
  ps  <- evaluate_mi_method("propensity", 30000L, 301L)

  # Bonferroni and Holm are identical across the two variance-version tables.
  shrink$bonf_reg <- nonshrink$bonf_reg <- reg$bonf
  shrink$holm_reg <- nonshrink$holm_reg <- reg$holm
  shrink$bonf_pmm <- nonshrink$bonf_pmm <- pmm$bonf
  shrink$holm_pmm <- nonshrink$holm_pmm <- pmm$holm
  shrink$bonf_ps <- nonshrink$bonf_ps <- ps$bonf
  shrink$holm_ps <- nonshrink$holm_ps <- ps$holm

  # Proposed method differs by shrinkage version.
  shrink$prop_reg <- reg$prop_shrink
  shrink$prop_pmm <- pmm$prop_shrink
  shrink$prop_ps <- ps$prop_shrink

  nonshrink$prop_reg <- reg$prop_nonshrink
  nonshrink$prop_pmm <- pmm$prop_nonshrink
  nonshrink$prop_ps <- ps$prop_nonshrink

  list(
    shrink = shrink,
    nonshrink = nonshrink
  )
}

# ---------------------------------------------------------------------------
# 10. ONE REPLICATION WRAPPER
# ---------------------------------------------------------------------------
simulate_one_rep <- function(sim,
                             n_each,
                             mu_vec,
                             setting_seed,
                             joint_type = c("fwer", "power")) {
  joint_type <- match.arg(joint_type)

  tryCatch({
    seed_data <- setting_seed + sim * 100000L
    seed_miss <- seed_data + 1000L
    seed_eval <- seed_data + 2000L

    dat_full <- make_complete_data(
      n_each = n_each,
      mu_vec = mu_vec,
      seed = seed_data
    )

    dat_miss <- impose_missingness_mar(
      dat_full,
      seed = seed_miss
    )

    ev <- evaluate_one_dataset(
      dat_miss,
      seed_base = seed_eval,
      alpha_level = alpha
    )

    make_result_matrix <- function(one_version) {
      method_names <- names(one_version)
      result <- matrix(
        0L,
        nrow = length(method_names),
        ncol = k_treat + 1L,
        dimnames = list(method_names, c(treat_levels, "Joint"))
      )

      for (nm in method_names) {
        rej <- one_version[[nm]]
        result[nm, treat_levels] <- as.integer(rej[treat_levels])

        if (joint_type == "fwer") {
          result[nm, "Joint"] <- as.integer(any(rej))
        } else {
          result[nm, "Joint"] <- as.integer(all(rej))
        }
      }

      result
    }

    list(
      ok = TRUE,
      shrink = make_result_matrix(ev$shrink),
      nonshrink = make_result_matrix(ev$nonshrink),
      achieved_missing_rate = mean(is.na(dat_miss$y)),
      error = NA_character_
    )
  }, error = function(e) {
    list(
      ok = FALSE,
      shrink = NULL,
      nonshrink = NULL,
      achieved_missing_rate = NA_real_,
      error = conditionMessage(e)
    )
  })
}

# ---------------------------------------------------------------------------
# 11. RUN ONE N / SCENARIO SETTING
# ---------------------------------------------------------------------------
run_one_setting <- function(n_each,
                            mu_vec,
                            nsim = nsim_main,
                            seed = master_seed,
                            joint_type = c("fwer", "power")) {
  joint_type <- match.arg(joint_type)
  sim_ids <- seq_len(nsim)

  message(
    sprintf(
      "Running N=%d, joint_type=%s, nsim=%d ...",
      n_each,
      joint_type,
      nsim
    )
  )

  if (use_parallel && n_cores > 1L) {
    cl <- parallel::makeCluster(n_cores)
    on.exit(try(parallel::stopCluster(cl), silent = TRUE), add = TRUE)

    parallel::clusterEvalQ(cl, {
      library(mvtnorm)
      library(dplyr)
      library(tibble)
    })

    objects_to_export <- setdiff(ls(envir = .GlobalEnv), "cl")
    parallel::clusterExport(
      cl,
      varlist = objects_to_export,
      envir = .GlobalEnv
    )

    ans <- parallel::parLapplyLB(
      cl,
      sim_ids,
      simulate_one_rep,
      n_each = n_each,
      mu_vec = mu_vec,
      setting_seed = seed,
      joint_type = joint_type
    )

    parallel::stopCluster(cl)
  } else {
    ans <- lapply(
      sim_ids,
      simulate_one_rep,
      n_each = n_each,
      mu_vec = mu_vec,
      setting_seed = seed,
      joint_type = joint_type
    )
  }

  ok <- vapply(ans, `[[`, logical(1), "ok")
  n_success <- sum(ok)
  n_failed <- sum(!ok)

  if (n_success == 0L) stop("All simulations failed in this setting.")

  if (n_failed > 0L) {
    warning(sprintf("%d of %d simulations failed in this setting.", n_failed, nsim))
  }

  good <- ans[ok]

  shrink_sum <- Reduce(`+`, lapply(good, `[[`, "shrink"))
  nonshrink_sum <- Reduce(`+`, lapply(good, `[[`, "nonshrink"))

  failed_tbl <- if (n_failed == 0L) {
    tibble()
  } else {
    tibble(
      sim = sim_ids[!ok],
      error = vapply(ans[!ok], `[[`, character(1), "error")
    )
  }

  list(
    pct_shrink = 100 * shrink_sum / n_success,
    pct_nonshrink = 100 * nonshrink_sum / n_success,
    n_success = n_success,
    n_failed = n_failed,
    achieved_missing_rate = mean(
      vapply(good, `[[`, numeric(1), "achieved_missing_rate")
    ),
    failed = failed_tbl
  )
}

# ---------------------------------------------------------------------------
# 12. RUN FULL PAPER SIMULATION II
# ---------------------------------------------------------------------------
run_paper_sim2 <- function() {
  rows <- list()
  fail_rows <- list()
  rr <- 1L
  ff <- 1L

  for (ii in seq_along(n_grid)) {
    n_now <- n_grid[ii]

    # Scenario I: FWER = at least one false rejection.
    s1 <- run_one_setting(
      n_each = n_now,
      mu_vec = mu_scen1,
      nsim = nsim_main,
      seed = master_seed + ii * 10000000L + 1000000L,
      joint_type = "fwer"
    )

    rows[[rr]] <- list(
      Scenario = "Scenario I",
      N = n_now,
      shrink = s1$pct_shrink,
      nonshrink = s1$pct_nonshrink,
      n_success = s1$n_success,
      n_failed = s1$n_failed,
      achieved_mr = s1$achieved_missing_rate
    )
    rr <- rr + 1L

    if (nrow(s1$failed) > 0L) {
      fail_rows[[ff]] <- s1$failed %>%
        mutate(Scenario = "Scenario I", N = n_now)
      ff <- ff + 1L
    }

    # Scenario II: individual power and joint power = reject all ten nulls.
    s2 <- run_one_setting(
      n_each = n_now,
      mu_vec = mu_scen2,
      nsim = nsim_main,
      seed = master_seed + ii * 10000000L + 2000000L,
      joint_type = "power"
    )

    rows[[rr]] <- list(
      Scenario = "Scenario II",
      N = n_now,
      shrink = s2$pct_shrink,
      nonshrink = s2$pct_nonshrink,
      n_success = s2$n_success,
      n_failed = s2$n_failed,
      achieved_mr = s2$achieved_missing_rate
    )
    rr <- rr + 1L

    if (nrow(s2$failed) > 0L) {
      fail_rows[[ff]] <- s2$failed %>%
        mutate(Scenario = "Scenario II", N = n_now)
      ff <- ff + 1L
    }
  }

  list(
    rows = rows,
    failures = if (length(fail_rows) == 0L) tibble() else bind_rows(fail_rows)
  )
}

# ---------------------------------------------------------------------------
# 13. FORMAT REFERENCE-PAPER-STYLE TABLE FOR ONE VARIANCE VERSION
#     Cell order = PS / PMM / RE
# ---------------------------------------------------------------------------
fmt_pct <- function(x) sprintf("%.2f", x)
fmt_three <- function(ps, pmm, re) {
  sprintf("%.2f/%.2f/%.2f", ps, pmm, re)
}

extract_version_pct <- function(row_obj, variance_version) {
  if (variance_version == "shrinkage") row_obj$shrink else row_obj$nonshrink
}

format_paper_sim2_table <- function(sim_out,
                                    variance_version = c("shrinkage", "non-shrinkage")) {
  variance_version <- match.arg(variance_version)
  out <- list()
  kk <- 1L

  all_N <- sort(unique(vapply(sim_out$rows, `[[`, numeric(1), "N")))

  for (n_now in all_N) {
    s1_obj <- sim_out$rows[
      vapply(
        sim_out$rows,
        function(z) z$N == n_now && z$Scenario == "Scenario I",
        logical(1)
      )
    ][[1]]

    s2_obj <- sim_out$rows[
      vapply(
        sim_out$rows,
        function(z) z$N == n_now && z$Scenario == "Scenario II",
        logical(1)
      )
    ][[1]]

    p1 <- extract_version_pct(s1_obj, variance_version)
    p2 <- extract_version_pct(s2_obj, variance_version)

    row_fwer <- tibble(
      N = n_now,
      Scenario = "Scenario I",
      Metric = "Joint Test (Family-wise error rate)",
      Naive = fmt_pct(p1["naive", "Joint"]),
      Single = fmt_pct(p1["single", "Joint"]),
      Bonferroni = fmt_three(
        p1["bonf_ps", "Joint"],
        p1["bonf_pmm", "Joint"],
        p1["bonf_reg", "Joint"]
      ),
      Holm = fmt_three(
        p1["holm_ps", "Joint"],
        p1["holm_pmm", "Joint"],
        p1["holm_reg", "Joint"]
      ),
      Proposed = fmt_three(
        p1["prop_ps", "Joint"],
        p1["prop_pmm", "Joint"],
        p1["prop_reg", "Joint"]
      )
    )

    power_rows <- lapply(seq_along(treat_levels), function(jj) {
      tr <- treat_levels[jj]

      tibble(
        N = n_now,
        Scenario = "Scenario II",
        Metric = paste0(tr, " vs. T0 (Power)"),
        Naive = fmt_pct(p2["naive", tr]),
        Single = fmt_pct(p2["single", tr]),
        Bonferroni = fmt_three(
          p2["bonf_ps", tr],
          p2["bonf_pmm", tr],
          p2["bonf_reg", tr]
        ),
        Holm = fmt_three(
          p2["holm_ps", tr],
          p2["holm_pmm", tr],
          p2["holm_reg", tr]
        ),
        Proposed = fmt_three(
          p2["prop_ps", tr],
          p2["prop_pmm", tr],
          p2["prop_reg", tr]
        )
      )
    })

    row_joint <- tibble(
      N = n_now,
      Scenario = "Scenario II",
      Metric = "Joint Test (Power to reject all ten nulls)",
      Naive = fmt_pct(p2["naive", "Joint"]),
      Single = fmt_pct(p2["single", "Joint"]),
      Bonferroni = fmt_three(
        p2["bonf_ps", "Joint"],
        p2["bonf_pmm", "Joint"],
        p2["bonf_reg", "Joint"]
      ),
      Holm = fmt_three(
        p2["holm_ps", "Joint"],
        p2["holm_pmm", "Joint"],
        p2["holm_reg", "Joint"]
      ),
      Proposed = fmt_three(
        p2["prop_ps", "Joint"],
        p2["prop_pmm", "Joint"],
        p2["prop_reg", "Joint"]
      )
    )

    out[[kk]] <- bind_rows(
      row_fwer,
      bind_rows(power_rows),
      row_joint
    )
    kk <- kk + 1L
  }

  bind_rows(out)
}

# ---------------------------------------------------------------------------
# 14. GT TABLE
# ---------------------------------------------------------------------------
make_paper_sim2_gt <- function(table_df,
                               variance_version = c("shrinkage", "non-shrinkage")) {
  variance_version <- match.arg(variance_version)

  scen1_txt <- paste0(
    "mu(0)=0, ",
    paste0("mu(", 1:n_treatments, ")=0", collapse = ", ")
  )

  scen2_txt <- paste0(
    "mu(0)=0, ",
    paste0(
      "mu(", 1:n_treatments, ")=",
      format(mu_scen2[treat_levels], trim = TRUE),
      collapse = ", "
    )
  )

  display_df <- table_df %>%
    mutate(
      Block = case_when(
        Scenario == "Scenario I" ~ paste0("N = ", N, "   Scenario I: ", scen1_txt),
        Scenario == "Scenario II" ~ paste0("N = ", N, "   Scenario II: ", scen2_txt)
      ),
      MetricOrder = case_when(
        Metric == "Joint Test (Family-wise error rate)" ~ 1L,
        grepl("^T[0-9]+ vs\\. T0", Metric) ~ as.integer(sub("^T([0-9]+).*", "\\1", Metric)) + 1L,
        TRUE ~ 100L
      )
    ) %>%
    arrange(N, Scenario, MetricOrder)

  title_txt <- if (variance_version == "shrinkage") {
    "Paper Simulation II: unequal-variance shrinkage version with 10 treatments"
  } else {
    "Paper Simulation II: unequal-variance non-shrinkage version with 10 treatments"
  }

  display_df %>%
    gt(
      rowname_col = "Metric",
      groupname_col = "Block"
    ) %>%
    cols_hide(columns = c(N, Scenario, MetricOrder)) %>%
    tab_header(
      title = title_txt,
      subtitle = paste0(
        "30% expected missingness; N=40/80 per arm; m=40; 10,000 simulations; ",
        "Multiple cells shown as PS / PMM / RE"
      )
    ) %>%
    tab_spanner(
      label = "Multiple (PS / PMM / RE)",
      columns = c(Bonferroni, Holm, Proposed)
    ) %>%
    cols_label(
      Naive = "Naive",
      Single = "Single",
      Bonferroni = "Bonferroni",
      Holm = "Holm's",
      Proposed = "Proposed"
    ) %>%
    cols_align(
      align = "center",
      columns = c(Naive, Single, Bonferroni, Holm, Proposed)
    ) %>%
    tab_style(
      style = cell_text(weight = "bold"),
      locations = cells_row_groups()
    ) %>%
    tab_source_note(
      source_note = paste0(
        "PS = propensity-score MI; PMM = predictive mean matching; ",
        "RE = regression MI. X~N(0,1), rho(X,Y|arm)=0.50, ",
        "logistic MAR OR=2 per 1-SD increase in X. ",
        "PMM K=5; propensity subclasses G=3."
      )
    ) %>%
    tab_options(
      table.font.size = px(10),
      heading.title.font.size = px(14),
      heading.subtitle.font.size = px(10),
      data_row.padding = px(3),
      row_group.padding = px(4),
      table.border.top.width = px(1.2),
      table.border.bottom.width = px(1.2),
      column_labels.border.top.width = px(0.8),
      column_labels.border.bottom.width = px(0.8),
      row_group.border.top.width = px(0.8),
      row_group.border.bottom.width = px(0.8),
      table_body.hlines.width = px(0.6)
    )
}

# ---------------------------------------------------------------------------
# 15. RUN EVERYTHING
# ---------------------------------------------------------------------------
message("============================================================")
message("THESIS_HABIB - Paper Simulation II")
message("10 treatments + 1 control | unequal variance")
message(sprintf("N per arm: %s", paste(n_grid, collapse = ", ")))
message(sprintf("Expected missing rate: %.0f%%", 100 * mr_fixed))
message(sprintf("Imputations: %d", m_imp))
message(sprintf("Monte Carlo simulations per N/scenario: %d", nsim_main))
message(sprintf("rho(X,Y|arm): %.2f", rho_xy))
message(sprintf("OR missingness per 1-SD X: %.2f", mar_odds_ratio_per_sd))
message(sprintf("PMM K: %d | Propensity G: %d", pmm_donors, propensity_groups))
message(sprintf("Calibrated MAR intercept: %.6f", alpha_mar_30))
message(sprintf("Parallel: %s | cores: %d", use_parallel, ifelse(use_parallel, n_cores, 1L)))
message("============================================================")

sim_out <- run_paper_sim2()

paper_sim2_shrinkage_table <- format_paper_sim2_table(
  sim_out,
  variance_version = "shrinkage"
)

paper_sim2_nonshrinkage_table <- format_paper_sim2_table(
  sim_out,
  variance_version = "non-shrinkage"
)

print(paper_sim2_shrinkage_table, n = Inf)
print(paper_sim2_nonshrinkage_table, n = Inf)

paper_sim2_shrinkage_gt <- make_paper_sim2_gt(
  paper_sim2_shrinkage_table,
  variance_version = "shrinkage"
)

paper_sim2_nonshrinkage_gt <- make_paper_sim2_gt(
  paper_sim2_nonshrinkage_table,
  variance_version = "non-shrinkage"
)

paper_sim2_shrinkage_gt
paper_sim2_nonshrinkage_gt

# Save primary tables.
write.csv(
  paper_sim2_shrinkage_table,
  "paper_sim2_10treat_shrinkage_N40_N80_table.csv",
  row.names = FALSE
)

write.csv(
  paper_sim2_nonshrinkage_table,
  "paper_sim2_10treat_nonshrinkage_N40_N80_table.csv",
  row.names = FALSE
)

gtsave(
  paper_sim2_shrinkage_gt,
  "paper_sim2_10treat_shrinkage_N40_N80_table.html"
)

gtsave(
  paper_sim2_nonshrinkage_gt,
  "paper_sim2_10treat_nonshrinkage_N40_N80_table.html"
)

# Save failures if any. At N=40/80 and 30% missingness, failures should be rare.
if (nrow(sim_out$failures) > 0L) {
  write.csv(
    sim_out$failures,
    "paper_sim2_10treat_N40_N80_failed_jobs.csv",
    row.names = FALSE
  )
  message("WARNING: Some simulations failed. See paper_sim2_10treat_N40_N80_failed_jobs.csv")
} else {
  message("Simulation finished with zero failed Monte Carlo jobs.")
}

# Expected missingness check.
message(
  sprintf(
    "Calibrated E[P(M=1|X)] = %.8f",
    mean_mar_probability(alpha_mar_30)
  )
)
